<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PATH</title>
    <link rel="stylesheet" href="./Search_Ku.css">
    <script src="https://kit.fontawesome.com/c881082b49.js" crossorigin="anonymous"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
</head>
<body>
<script>

</script>

    <!-- php연동 -->
    <?php

    // $servername = "localhost:3306";
    $servername = "127.0.0.1";
    $username = "root";
    $password = "0918";
    $dbname = "Path";
    ?>

    <div class="top">
        <div class="Title">
        PATH
        </div>
        <div class="Login">
            <button type="button" aria-label="Login" class="Login-button">
                Login
            </button>
        </div>
    </div>
    <div class="topbar" style="position: absolute; top:0;">
        
        <!-- 왼쪽 서브 메뉴 -->
        <!-- 잠시 사이드메뉴 접어놓기 -->
        <div class="left_side_bar">
            <div class="Ku">
                <h2>구별 검색</h2>
                <ul class="Ku_list">
                    <li>ㄱ<i class="arrow fas fa-angle-right "></i></li>
                    <ul class="specific_Ku">
                        <li><a href="#" >강동구</a></li>
                        <li><a href="#" >광진구</a></li>
                        <li><a href="#" >강북구</a></li>
                        <li><a href="#" >강서구</a></li>
                        <li><a href="#" >구로구</a></li>
                        <li><a href="#" >금천구</a></li>
                        <li><a href="#" >관약구</a></li>
                        <li><a href="#" >강남구</a></li>
                    </ul>
                </ul>
                <ul class="Ku_list ">
                    <li>ㄴ<i class="arrow fas fa-angle-right"></i></li>
                    <ul class="specific_Ku">
                        <li><a href="#" >노원구</a></li>
                    </ul>
                </ul>
                <ul class="Ku_list ">
                    <li>ㄷ<i class="arrow fas fa-angle-right"></i></li>
                    <ul class="specific_Ku">
                        <li><a href="#" >동대문구</a></li>
                        <li><a href="#" >도봉구</a></li>
                        <li><a href="#" >동작구</a></li>
    

                    </ul>
                </ul>
                <ul class="Ku_list ">
                    <li>ㅁ<i class="arrow fas fa-angle-right"></i></li>
                    <ul class="specific_Ku">
                        <li><a href="#" >마포구</a></li>


                    </ul>
                </ul>
                <ul class="Ku_list ">
                    <li>ㅅ<i class="arrow fas fa-angle-right"></i></li>
                    <ul class="specific_Ku">
                        <li><a href="#" >송파구</a></li>
                        <li><a href="#" >서초구</a></li>
                        <li><a href="#" >서대문구</a></li>
                        <li><a href="#" >성북구</a></li>
                        <li><a href="#" >성동구</a></li>
    

                    </ul>
                </ul>
                <ul class="Ku_list ">
                    <li>ㅇ<i class="arrow fas fa-angle-right"></i></li>
                    <ul class="specific_Ku">
                        <li><a href="#" >용산구</a></li>
                        <li><a href="#" >은평구</a></li>
                        <li> <a href="#" >양천구</a></li>
                        <li><a href="#" >영등포구</a></li>
    

                    </ul>
                </ul>
                <ul class="Ku_list ">
                    <li>ㅈ<i class="arrow fas fa-angle-right"></i></li>
                    <ul class="specific_Ku">
                        <li><a href="#" >중랑구</a></li>
                        <li><a href="#" >중구구</a></li>
                        <li><a href="#" >종로구</a></li>
    

                    </ul>
                </ul>

            </div>
            <div class="Ku">
                <h2>호선별 검색</h2>
            </div>
            <ul class="specific_Line">
                <li><a href="#">1호선</a></li>
                <li><a href="#">2호선</a></li>
                <li><a href="#">3호선</a></li>
                <li><a href="#">4호선</a></li>
                <li><a href="#">5호선</a></li>
                <li><a href="#">6호선</a></li>
                <li><a href="#">7호선</a></li>
                <li><a href="#">8호선</a></li>
                <li><a href="#">9호선</a></li>
            </ul>
        </div>
    </div>
    </div>


    <!-- 라디오 버튼 클릭시 출력되도록 -->

    <div class="sort">
    <form method="get" action="form-action.html">
        <h1><p>검색을 원하는 편의시설을 선택해 주세요</p></h1>
        <label>
            <!-- 테스트 해보는 중! -->
        <input type="radio" name="sort" value="overpass"
             <?php $sql="select * from overpass"; ?>
        > 육교
        </label>
        <label><input type="radio" name="sort" value="charge"
            <?php $sql="select * from district_facility"; ?>
        > 충전소</label>
        <button type="button" aria-label="Search" class="Search-button">검색</button>
            <!-- 테스트 -->
        <h6>*리프트 검색은 호선별 검색이나 통합 검색을 이용해 주세요.</br></h6>
        
    </div>

    <div class="searchbox">
        <table border="1">
            <tr>
                <th>육교 이름</th>
                <th>육교 주소</th>
                <th>편의시설 종류</th>
                <th>편의시설 수</th>
            </tr>
            <!-- 값 전달 -->
            

            <?php
                $conn = new mysqli($servername, $username, $password, $dbname);
                
                if($conn->connect_error){
                    die("접속실패: ". $conn->connect_error);
                }else{
                    // echo "성공";
                }

                //////////여기가 sql
                $sql="select * from overpass where O_address like '%강동%'";

                $result = mysqli_query($conn, $sql);
                
                if(mysqli_num_rows($result) > 0){
                while($row = mysqli_fetch_assoc($result)) { //이름을 키값으로
                    echo "<tr>";
                    echo "<td>".$row["O_name"]."</td>";
                    echo "<td>".$row['O_address']."</td>";
                    echo "<td>".$row['convenience_sort']."</td>";
                    echo "<td>".$row['convenience_num']."</td>";
                    echo "</tr>";
                }
                }else{
                    echo "비정상";
                }
            ?>
        </table>
    </div>

    <div class="searchbox">
    <table border="1">
            <tr>
                <th>충전소 이름</th>
                <th>충전소 주소</th>
                <th>충전소 설명</th>
                <th>동시 사용 가능 대수</th>
            </tr>
            <!-- 값 전달 -->
            

            <?php
                //////////여기가 sql
                $sql2="select *
                from wc_convenience as c, wc_conv_info as i
                where (c.wc_number = i.wc_number) and (i.wc_address like '%강동%');";

                
                $result = mysqli_query($conn, $sql2);
                
                if(mysqli_num_rows($result) > 0){
                while($row = mysqli_fetch_array($result)) { //이름을 키값으로
                    echo "<tr>";
                    echo "<td>".$row["WC_name"]."</td>";
                    echo "<td>".$row['WC_address']."</td>";
                    echo "<td>".$row['Explanation']."</td>";
                    echo "<td>".$row['simultaneously_use_num']."</td>";
                    echo "</tr>";
                }
                }else{
                    echo "비정상";
                }
            ?>
        </table>
    </div>
<!-- IONICONS -->
<script src="https://unpkg.com/ionicons@5.2.3/dist/ionicons.js"></script>
<!-- JS -->
<script src="./Search.js"></script>
<script src="./Search_Ku.js"></script>

<script>
    $(function () {
        // 왼쪽메뉴 드롭다운
        $(".Ku ul.specific_ku").hide();
        $(".Ku ul.Ku_list").click(function () {
            $("ul", this).slideToggle(300);
        });
        // 외부 클릭 시 좌측 사이드 메뉴 숨기기
        $('.overlay').on('click', function () {
            $('.left_sub_menu').fadeOut();
            $('.hide_sidemenu').fadeIn();
        });
    });
</script>
</body>